# Determent on your existing Cloudflare Worker

The deployment target supplied in this conversation is:

- Worker: `tight-frost-35c6`
- Account ID: `0c4b7b6d3ddd0cad5b4bd90b366fdee0` (non-secret)
- Address: https://tight-frost-35c6.certifiedcoal.workers.dev/

`wrangler.jsonc` deploys the complete static game to this Worker. It keeps the same address. The game needs no backend or build command. `_headers` asks browsers to revalidate files on refresh; there is no service worker holding an old game version. Browser-local saves remain on the same Cloudflare origin.

## Enable direct updates from this workspace

1. In Cloudflare, open your profile’s **API Tokens** and create an account-scoped custom token. Give it **Account → Workers Scripts → Edit** and **Account → Account Settings → Read**, limited to the account above. A global API key is unnecessary.
2. Store the value through the managed environment’s secure secret configuration, with the variable name `CLOUDFLARE_API_TOKEN`. Complete the environment configuration review. Do not paste the value into chat, source files, the browser game, or a command argument. Do not put it in this static Site’s runtime variables: the deployment credential belongs to the execution environment.
3. Tell the assistant that the environment secret is configured. It can check credential readiness, verify the account subdomain and existing Worker, then deploy this prepared update.

The environment currently has no Cloudflare credential, so the prepared configuration alone does **not** update the live Worker. Once authentication is ready, future requested updates can be published to the same URL and players can refresh. This is a deployment workflow for updates requested in chat; it does not run an unattended background updater.

## Deployment commands

Install the official Wrangler CLI in a development environment (`npm install -g wrangler@4`), then:

```sh
python bundle-cloudflare.py
python cloudflare-deploy.py --check-only
python cloudflare-deploy.py
```

A locally installed CLI can be selected with `--wrangler /absolute/path/to/wrangler`. The helper reads the token only from the inherited environment. Before any write, it checks that this account uses the `certifiedcoal` Workers subdomain and contains `tight-frost-35c6`. It refuses a changed or missing target. Wrangler uploads the static game with `keep_vars` enabled. This replaces the Worker’s game deployment; any unrelated Worker application logic would need its own configuration before combining the two.

For an unauthenticated bundle/config check:

```sh
wrangler deploy --dry-run --config wrangler.jsonc --outdir /tmp/determent-worker-dry-run
```

## Dashboard upload alternative

Download the current [ready-to-upload game ZIP](https://determent.daringbuddy6.chatgpt.site/downloads/determent-cloudflare.zip). It contains `index.html` at the root, all four scripts, styles, cartoon artwork, scene illustrations, audio, and refresh headers. It excludes credentials and deployment source.

For a Pages Direct Upload project, open **Workers & Pages → Create application → Pages → Direct Upload**, give the project a name, upload the ZIP, and deploy. Dashboard labels may vary. This creates a separate `.pages.dev` address; it does not update the existing `tight-frost-35c6` Worker. For an existing Pages project, upload a new deployment to that project.

Sound begins after the first click or key press. Saves and sound settings are stored per browser and site origin; moving from Sites to Cloudflare starts a separate checkpoint. The existing Sites publication keeps its owner-private audience.

Official references: [Worker static assets](https://developers.cloudflare.com/workers/static-assets/), [API tokens](https://developers.cloudflare.com/fundamentals/api/get-started/create-token/), [Pages dashboard uploads](https://developers.cloudflare.com/pages/get-started/direct-upload/).
