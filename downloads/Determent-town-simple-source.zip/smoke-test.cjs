const {createHarness}=require('./test-harness.cjs');
const {g,els,storage,sandbox,cues,assert,fs}=createHarness();
setTimeout(()=>{
for(const klass of ['oathbound','cinderborn','veilwalker']){
 cues.length=0;g.start(klass);let h=g.hero();assert.equal(g.state(),'paused');assert(els.get('#panel').innerHTML.includes('A bell in the rain'));const beforeScene=h.hp;g.update(1);assert.equal(h.hp,beforeScene);g.advanceScene();assert(els.get('#scene-line').textContent.length>0);g.skipScene();assert.equal(g.state(),'playing');g.travel('field');assert.equal(g.enemies().length,7);g.render(1);if(klass==='oathbound')fs.writeFileSync('/tmp/determent-art-scene.png',els.get('#world').toBuffer('image/png'));
 const oldResolve=h.resolve;g.ability('nova');assert(h.resolve<oldResolve);let cd=h.cool.nova;g.ability('nova');assert.equal(h.cool.nova,cd);g.update(1);assert(h.resolve>oldResolve-40);
 h.hp=10;g.ability('potion');assert(h.hp>10);assert.equal(h.flasks,2);
 for(let seal=0;seal<3;seal++){
  const loc=[[-290,-260],[320,-210],[70,345]][seal];h.x=loc[0];h.y=loc[1];g.interact();assert.equal(g.game().activeSeal,seal);assert(g.enemies().some(e=>e.seal===seal));
  for(const e of g.enemies().slice())g.hurt(e,9999);g.update(.016);assert(g.game().seals[seal]);assert.equal(g.state(),'paused');assert.equal(g.objectiveRows().filter(r=>r.done).length,seal+1);g.skipScene();assert.equal(g.state(),'playing');
  const relic=g.loot().find(v=>v.type==='relic');if(relic){h.x=relic.x;h.y=relic.y;g.update(.016);}assert(h.inventory.length>=seal+2);
 }
 assert(g.game().bossSpawned);const boss=g.enemies().find(e=>e.boss);assert(boss);h.x=boss.x+40;h.y=boss.y+40;h.resolve=100;h.cool.special=0;let hp=boss.hp;g.ability('special');if(klass!=='cinderborn')assert(boss.hp<hp);g.update(.05);g.skipScene();g.render(1);fs.writeFileSync('/tmp/determent-effect-'+klass+'.png',els.get('#world').toBuffer('image/png'));if(klass==='cinderborn')assert(boss.hp<hp);
 for(let i=0;i<32;i++)g.update(.016);g.render(1);if(klass==='oathbound')fs.writeFileSync('/tmp/determent-game.png',els.get('#world').toBuffer('image/png'));
 g.hurt(boss,9999);g.update(.016);assert(g.game().bossDefeated);h.x=0;h.y=-450;g.interact();assert.equal(g.state(),'ending');g.finishEnding('release');assert(els.get('#panel').innerHTML.includes('scene-still'));g.skipScene();assert(g.game().finished);assert(g.objectiveRows().every(r=>r.done));assert(els.get('#panel').innerHTML.includes('The first true morning'));g.finishEnding('bind');g.skipScene();assert(els.get('#panel').innerHTML.includes('One more dawn'));
 const saved=JSON.parse(storage.get('determent-v1'));assert(saved.seals.every(Boolean));assert(saved.finished);g.start(klass,saved);assert.equal(g.hero().level,saved.level);assert.equal(g.hero().inventory.length,saved.inventory.length);assert(g.objectiveRows().every(r=>r.done));assert(!g.enemies().some(e=>e.boss));
 h=g.hero();h.invuln=0;g.hitHero(9999);assert.equal(g.state(),'dead');g.revive();assert.equal(g.state(),'playing');assert(g.hero().hp>0);
 assert(cues.includes({oathbound:'rend',cinderborn:'storm',veilwalker:'shadow'}[klass]));for(const cue of ['nova','heal','sealWake','sealClear','bossWake','bossDeath','relic','release','bind','death','objective'])assert(cues.includes(cue),klass+' missing '+cue);
 console.log('PASS '+klass+': abilities, recovery, three seals, loot, boss, both endings, persistence, death and revive');
}
// Quiet thoughts appear without pausing or repeating, and particles remain bounded.
g.start('oathbound');g.skipScene();for(const e of g.enemies())e.active=false;g.hero().moving=false;g.updateNarrative(14);assert(g.game().thoughtsSeen.includes('town-hearth'));assert.equal(g.state(),'playing');assert(els.get('#thought').innerHTML.includes('YOUR EXILE'));const thoughtCount=g.game().thoughtsSeen.length;g.updateNarrative(1);assert.equal(g.game().thoughtsSeen.length,thoughtCount);
const v=sandbox.window.DetermentVisuals;for(let i=0;i<100;i++)v.emit('storm',{x:0,y:0});assert(v.status().particles<=360);v.toggleCalm();v.impact('hurt');assert.equal(v.offset().x,0);v.update(4,true);assert.equal(v.status().particles,0);assert.equal(v.status().rings,0);
console.log('PASS illustrated scene pause/skip/persistence, completed objectives and cues, quiet thoughts, bounded effects, calm motion, and Canvas rendering');

}, 100);
