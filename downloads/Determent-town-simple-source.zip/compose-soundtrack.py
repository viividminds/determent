"""Original Determent score: three synchronized 32-second stems, no borrowed samples.

Run with Python (numpy/scipy) and ffmpeg to rebuild the shipped MP3s.
The eight-bar D-minor motif moves through Dm, Bb, Gm and suspended A.
Reverb tails wrap across the loop boundary rather than fading to silence.
"""
from pathlib import Path
import subprocess
import numpy as np
from scipy import signal
from scipy.io import wavfile

SR, SECONDS = 32000, 32
N = SR * SECONDS
rng = np.random.default_rng(714)
root = Path(__file__).resolve().parent
output = root / 'dist/assets/audio'
output.mkdir(parents=True, exist_ok=True)
work = Path('/tmp/determent-score')
work.mkdir(exist_ok=True)

def hz(note):
    return 440 * 2 ** ((note - 69) / 12)

def envelope(t, duration, attack=.4, release=1.5):
    return np.minimum(1, t / attack) * np.minimum(1, np.maximum(0, (duration - t) / release))

def instrument(note, duration, kind):
    t = np.arange(int(duration * SR)) / SR
    f = hz(note)
    if kind in ('strings', 'choir'):
        # Small independent detunings and slow vibrato avoid an organ-like pure tone.
        phase = 2*np.pi*f*t + .055*np.sin(2*np.pi*4.7*t)
        x = np.zeros(len(t))
        for detune in (-.0018, 0, .0021):
            for h in range(1, 13):
                if kind == 'strings':
                    weight = 1 / h**1.65
                else:
                    weight = (np.exp(-((f*h-550)/240)**2)+.45*np.exp(-((f*h-1050)/360)**2)+.24) / h**1.3
                x += weight*np.sin(h*phase*(1+detune)+h*.3) / 3
        noise = signal.sosfilt(signal.butter(2, [250, 1500], fs=SR, btype='band', output='sos'), rng.normal(0, 1, len(t)))
        return (x + noise*.016)*envelope(t, duration, .7, 1.4)
    if kind == 'pluck':
        return sum(np.sin(2*np.pi*f*h*t+h*.3)*np.exp(-t*(.8+h*.27))/h**1.8 for h in range(1, 9))*envelope(t,duration,.014,.45)
    if kind == 'bell':
        return sum(np.sin(2*np.pi*f*r*t)*np.exp(-t*(.35+i*.15))/(1+i)**1.55 for i,r in enumerate([1,2.006,2.76,4.07,5.43]))*envelope(t,duration,.008,.5)
    if kind == 'drum':
        phase = 2*np.pi*(f*t + 80*.04*(1-np.exp(-t/.04)))
        skin = signal.sosfilt(signal.butter(2, 950, fs=SR, output='sos'),rng.normal(0,1,len(t)))
        return (np.sin(phase)*np.exp(-t*5)+skin*.22*np.exp(-t*18))*envelope(t,duration,.006,.15)
    raise ValueError(kind)

def add(track, note, at, duration, amp, kind, pan=0):
    x = instrument(note,duration,kind)*amp
    idx = (int(at*SR)+np.arange(len(x))) % N
    track[idx,0] += x*np.sqrt((1-pan)/2)
    track[idx,1] += x*np.sqrt((1+pan)/2)

def chamber(track):
    result = track.copy()
    for i,(delay,volume) in enumerate([(.079,.12),(.137,.1),(.223,.09),(.347,.075),(.557,.06),(.887,.05),(1.337,.035),(1.913,.025)]):
        result += np.roll(track[:, ::-1] if i%2 else track, int(delay*SR), axis=0)*volume
    # Gentle saturation, no brick-wall loudness or harsh high frequencies.
    result = np.tanh(result*1.1)/1.1
    return result

stems = {name: np.zeros((N,2)) for name in ('covenant','combat','bellkeeper')}
chords = [[38,45,53],[38,45,53],[34,41,50],[34,41,50],[31,38,46],[31,38,46],[33,40,50],[33,40,48]]
for bar, chord in enumerate(chords):
    at = bar*4
    for i,note in enumerate(chord):
        add(stems['covenant'],note,at,5.6,.052,'strings',(i-1)*.42)
        if bar%2 == 0:
            add(stems['covenant'],note+12,at+.15,8.4,.024,'choir',(1-i)*.32)
    for beat in (0,2):
        add(stems['combat'],chord[0],at+beat,1.4,.11,'drum',-.18 if beat==0 else .2)
    for beat in range(4):
        add(stems['combat'],chord[0]+12 if beat%2==0 else chord[1]+12,at+beat+.02,.8,.07,'strings',.18)
        add(stems['bellkeeper'],chord[0]-12,at+beat,.95,.1 if beat in (0,2) else .065,'drum',.1)
    add(stems['bellkeeper'],chord[0]+12,at,5.2,.058,'choir',-.2)
    if bar in (0,4):
        add(stems['bellkeeper'],chord[0]+12,at,6,.10,'bell',.3)
    for beat in (.75,1.5,2.75,3.5):
        add(stems['bellkeeper'],chord[1]+12,at+beat,.8,.043,'pluck',-.35)

# The same six-note "unpaid vow" motif returns in all eight bars, leaving space.
melody = [(62,1,2.4),(65,3,2),(64,5,2),(62,7,2.6),(57,10,3),(60,13,2.7),
          (62,17,2.4),(65,19,2),(67,21,2.2),(65,23,2.5),(64,26,2.6),(61,29,3.7)]
for i,(note,at,duration) in enumerate(melody):
    add(stems['covenant'],note,at,duration,.052,'pluck',-.25 if i%2 else .25)
add(stems['covenant'],62,0,7,.026,'bell',-.45)
add(stems['covenant'],57,16,7,.022,'bell',.45)

mastered = {}
for name,track in stems.items():
    track = chamber(track*2.5)
    track = signal.sosfilt(signal.butter(2, 6500, fs=SR, output='sos'),track,axis=0)
    assert np.isfinite(track).all()
    peak = float(np.max(np.abs(track)))
    assert 0 < peak < .9, (name,peak)
    mastered[name] = track
    wavfile.write(work/f'{name}.wav',SR,(track*32767).astype(np.int16))
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(work/f'{name}.wav'),'-codec:a','libmp3lame','-b:a','128k',str(output/f'{name}.mp3')],check=True)
    print(f'{name}: {SECONDS}s stereo, peak {peak:.3f}, RMS {np.sqrt(np.mean(track**2)):.3f}')
preview = mastered['covenant']*.7 + mastered['combat']*.52 + mastered['bellkeeper']*.45
wavfile.write(work/'preview.wav',SR,(preview*32767).astype(np.int16))
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(work/'preview.wav'),'-codec:a','libmp3lame','-b:a','128k',str(work/'preview.mp3')],check=True)
