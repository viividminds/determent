#!/usr/bin/env python3
"""Export tracked Determent source and assets, excluding downloads and local state."""
from pathlib import Path, PurePosixPath
import subprocess
import argparse
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, default=ROOT / 'dist' / 'downloads' / 'determent-source.zip')
OUTPUT = parser.parse_args().output
tracked = subprocess.run(['git', 'ls-files', '-z'], cwd=ROOT, check=True, capture_output=True).stdout
names = set(tracked.decode().split('\0')) - {''}
# Imported source need not be committed or staged to be included.
names.update(p.name for p in ROOT.iterdir() if p.is_file() and p.suffix in ('.md', '.py', '.cjs', '.jsonc'))
names.add('.gitignore')
names.update(p.relative_to(ROOT).as_posix() for p in (ROOT / 'dist').rglob('*') if p.is_file() and 'downloads' not in p.relative_to(ROOT / 'dist').parts)
files = []
for name in sorted(names):
    path = PurePosixPath(name)
    if name.startswith(('dist/downloads/', '.openai/local/')):
        continue
    if path.is_absolute() or '..' in path.parts or '.git' in path.parts:
        raise ValueError('Invalid export path')
    if path.name.startswith(('.env', '.dev.vars')) or path.suffix in ('.pem', '.key'):
        raise ValueError('Credential file cannot be exported')
    source = ROOT / name
    if source.is_symlink() or not source.is_file():
        raise ValueError(f'Export entry is not a regular source file: {name}')
    files.append(name)
required = ('wrangler.jsonc', 'cloudflare-deploy.py', 'dist/index.html', 'dist/game.js', 'dist/expansion.js', 'dist/town.js', 'SOURCE_EXPORT.md')
assert all(name in files for name in required)
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with ZipFile(OUTPUT, 'w', ZIP_DEFLATED, compresslevel=6) as archive:
    for name in files:
        archive.write(ROOT / name, name)
with ZipFile(OUTPUT) as archive:
    assert archive.testzip() is None
    assert archive.namelist() == files
    for name in files:
        assert archive.read(name) == (ROOT / name).read_bytes()
print(f'Exported and verified {len(files)} source files ({OUTPUT.stat().st_size:,} bytes): {OUTPUT}')
