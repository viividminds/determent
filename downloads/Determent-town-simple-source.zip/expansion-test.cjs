const {createHarness}=require('./test-harness.cjs');
const {g,els,storage,sandbox,assert,cues}=createHarness();
const X=sandbox.window.DetermentExpansion;
const at=s=>{g.hero().x=s.x;g.hero().y=s.y;};
const finish=()=>{g.skipScene();g.closePanel();};
setTimeout(()=>{
 for(const klass of ['oathbound','cinderborn','veilwalker']){
  g.start(klass,{klass,level:5,gold:400,sideQuests:{iron:{status:'claimed',progress:8}},skills:null});g.skipScene();
  assert.equal(g.game().sideQuests.iron.status,'claimed');assert.equal(g.game().sideQuests.seeds.status,'available');assert.equal(X.points(g.game().skills,5),5);
  g.learnSkill('signature');assert.equal(g.game().skills.signature,0,'prerequisite ignored');
  for(const node of ['vigor','guard','signature','edge','flow'])g.learnSkill(node);
  assert.equal(X.points(g.game().skills,5),0);assert.equal(g.game().skills.signature,1);g.learnSkill('edge');assert.equal(g.game().skills.edge,1,'overspent points');
  assert.equal(g.hero().maxHp,({oathbound:150,cinderborn:110,veilwalker:120}[klass])+80+15);g.closePanel();
  const gold=g.hero().gold;g.shopPurchase('temper');assert.equal(g.hero().gold,gold-60);assert.equal(g.game().upgrades,1);g.shopPurchase('bogus');assert.equal(g.game().upgrades,1);
  g.setPalette('wine');assert.equal(g.game().palette,'wine');g.closePanel();g.save();
  const saved=JSON.parse(storage.get('determent-v1'));g.start(klass,saved);assert.equal(g.game().skills.signature,1);assert.equal(g.game().upgrades,1);assert.equal(g.game().palette,'wine');
  g.travel('field');g.skipScene();const learned=g.game().skills.edge;g.learnSkill('edge');assert.equal(g.game().skills.edge,learned,'training allowed in combat field');
  for(const e of g.enemies()){e.x=g.hero().x+30;e.y=g.hero().y-30;e.active=true;e.hp=e.maxHp=1000;}
  const target=g.enemies()[0],hp=target.hp,resolve=g.hero().resolve;g.ability('signature');assert(g.hero().resolve<resolve);assert(g.hero().cool.signature>0);
  if(klass==='cinderborn'){assert.equal(g.effects().filter(e=>e.type==='bolt'&&e.friendly).length,5);g.update(.1);assert(target.hp<hp,'fire fan did not hit its target');}else assert(target.hp<hp);
  const once=g.hero().resolve;g.ability('signature');assert.equal(g.hero().resolve,once,'signature bypassed cooldown');
  g.travel('town');const spentGold=g.hero().gold;g.respecSkills();assert.equal(Object.values(g.game().skills).reduce((a,b)=>a+b,0),0);assert.equal(g.hero().gold,spentGold-50);assert.equal(X.points(g.game().skills,5),5);g.closePanel();
  console.log('PASS '+klass+': prerequisite and point limits, training stats, unique signature, cooldown, paid respec, forging/palette persistence, old-save quest migration');
 }
 // A telegraphed strike only deals damage after the warning and can be escaped.
 g.start('oathbound');g.skipScene();g.travel('field');g.enemies().splice(1);const foe=g.enemies()[0];Object.assign(foe,{x:0,y:80,type:'hollow',active:true,cd:0});g.hero().x=0;g.hero().y=70;g.hero().invuln=0;const hp=g.hero().hp;
 g.update(.016);assert(foe.windup>0);assert.equal(g.hero().hp,hp,'unannounced instant strike');at({x:200,y:200});g.update(.5);assert.equal(g.hero().hp,hp,'strike followed hero after telegraph');
 at({x:foe.x,y:foe.y});foe.cd=0;g.hero().invuln=0;g.update(.016);g.update(.5);assert(g.hero().hp<hp,'standing inside the warning did no damage');
 console.log('PASS combat warning delay, dodgeable fixed target, and damage on remaining in the warning');
 // Explore both optional roads without disturbing the main campaign checkpoint.
 for(const id of ['orchard','ossuary']){
  g.start('veilwalker',{klass:'veilwalker',level:4,chapter:2,seals:[true,false,true],gold:0});g.skipScene();const mainSeals=JSON.stringify(g.game().seals),r=X.regions[id];g.acceptQuest(r.quest);finish();g.travel(id);g.skipScene();
  assert.equal(g.game().region,id);assert.equal(JSON.stringify(g.game().seals),mainSeals);const count=g.enemies().length;
  at(r.sites[0]);g.interact();assert.equal(g.game().expeditions[id].found.length,0,'guardian gate bypassed');
  for(const e of g.enemies().slice())g.hurt(e,99999);g.update(.016);g.skipScene();assert.equal(g.enemies().length,0);
  for(const [i,site] of r.sites.entries()){at(site);g.interact();assert.equal(g.game().expeditions[id].found.length,i+1);g.skipScene();g.interact();assert.equal(g.game().expeditions[id].found.length,i+1,'duplicate memory credit');}
  assert.equal(g.game().sideQuests[r.quest].status,'ready');at({x:0,y:-440});const before=g.hero().gold;g.interact();assert.equal(g.hero().gold,before+r.reward);g.interact();assert.equal(g.hero().gold,before+r.reward,'cache duplicated');
  g.save();const saved=JSON.parse(storage.get('determent-v1'));g.start('veilwalker',saved);assert.equal(g.game().region,id);assert.equal(g.enemies().length,0,'cleared optional foes respawned');assert(g.game().expeditions[id].rewarded);
  g.travel('town');g.claimQuest(r.quest);finish();assert.equal(g.game().sideQuests[r.quest].status,'claimed');assert(g.hero().inventory.some(i=>i.name===X.quests[r.quest].relic));g.travel('field');g.skipScene();assert.equal(JSON.stringify(g.game().seals),mainSeals);
  console.log('PASS '+id+': '+count+' guardians, memory gate and conversations, quest turn-in, one-time cache, cleared-road reload, main-seal preservation');
 }
 g.start('cinderborn');g.skipScene();g.travel('ossuary');assert.equal(g.game().region,'town','locked road bypassed');
 g.talkNPC('fen');assert(els.get('#panel').innerHTML.includes('conversation-stage'));assert(!els.get('#panel').innerHTML.includes('conversation-lines'));const hpNow=g.hero().hp;cues.length=0;g.updateNarrative(.2);assert(cues.includes('voice'));assert(els.get('#scene-line').textContent.length>0);g.advanceNPC();g.advanceNPC();assert(els.get('#panel').innerHTML.includes('YOUR EXILE'));g.skipScene();assert(els.get('#panel').innerHTML.includes('Visit the stalls'));g.closePanel();assert.equal(g.hero().hp,hpNow);
 console.log('PASS locked-road gate, one-turn text reveal and voice cue, NPC/exile alternation, skip to services, and combat pause');
},120);
