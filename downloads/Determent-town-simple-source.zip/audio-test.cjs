// Render actual Web Audio signals offline, including the shipped MP3 score.
// Dev dependency only: npm install --prefix /tmp/determent-audio-qa web-audio-engine
// This engine implements oscillators/filters/mixing, but its convolver and
// compressor are passthroughs. Real browser listening is still needed for polish.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const {RenderingAudioContext}=require('/tmp/determent-audio-qa/node_modules/web-audio-engine');
const code=fs.readFileSync(__dirname+'/dist/audio.js','utf8');
const decoded={};
for(const name of ['covenant','combat','bellkeeper']) {
  const file='/tmp/determent-audio-qa/'+name+'.wav';
  assert(fs.existsSync(file),'Decode shipped MP3s to /tmp/determent-audio-qa/*.wav with ffmpeg first');
  const b=fs.readFileSync(file);decoded[name]=b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);
}
function setup({failed=false,saved=null,supported=true}={}) {
  let context,networkFailed=failed;
  const storage=new Map(saved?[['determent-audio-v1',JSON.stringify(saved)]]:[]);
  const starts=[];
  class AC extends RenderingAudioContext {
    constructor(){super({sampleRate:16000,channels:2});context=this;}
    createBufferSource(){const s=super.createBufferSource(),start=s.start.bind(s);s.start=(at=0)=>{starts.push({source:s,at});start(at);};return s;}
  }
  const sandbox={window:supported?{AudioContext:AC}:{},Math,console,
    localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},
    fetch:async url=>({ok:!networkFailed,arrayBuffer:async()=>decoded[url.split('/').at(-1).replace('.mp3','')]})};
  vm.runInNewContext(code,sandbox);
  return {a:sandbox.window.DetermentAudio,storage,starts,get ctx(){return context;},recover(){networkFailed=false;}};
}
async function settle(){for(let i=0;i<5;i++)await new Promise(r=>setImmediate(r));}
function run(w,seconds,data={state:'playing',health:1}) {
  const end=w.ctx.currentTime+seconds;
  while(w.ctx.currentTime<end){w.ctx._impl.changeState('running');w.a.update(.04,data);w.ctx.processTo(w.ctx.currentTime+.04);}
}
function stats(w,start=0,end=Infinity) {
  const data=w.ctx.exportAsAudioData(),from=Math.floor(start*data.sampleRate),to=Math.min(data.length,Math.floor(end*data.sampleRate));
  let energy=0,peak=0,n=0;
  for(const ch of data.channelData)for(let i=from;i<to;i++){assert(Number.isFinite(ch[i]));peak=Math.max(peak,Math.abs(ch[i]));energy+=ch[i]*ch[i];n++;}
  return {rms:Math.sqrt(energy/n),peak};
}
(async()=>{
  const w=setup();assert(!w.a.status().ready);w.a.unlock();await settle();assert(w.a.status().musicReady);
  const loops=w.starts.filter(x=>x.source.buffer?.duration>30);assert.equal(loops.length,3);
  assert(loops.every(x=>x.at===loops[0].at&&x.source.loopEnd===loops[0].source.loopEnd));
  assert(Math.abs(loops[0].source.loopEnd-32)<.01);
  run(w,3);assert.equal(w.a.status().scene,'courtyard');const calm=stats(w,1,3);
  // Ambient fire must remain a continuous bed, never a repeated UI-like transient.
  const idle=setup();idle.a.unlock();await settle();const idleStarts=idle.starts.length;
  run(idle,3,{state:'playing',health:1,moving:false,region:'town',player:{x:0,y:0},torch:{x:20,y:0}});
  assert.equal(idle.starts.length,idleStarts,'idle fire repeatedly started percussive sources');
  assert.equal(idle.a.status().activeVoices,0,'idle ambience allocated effect voices');
  run(idle,1,{state:'playing',health:1,moving:true,klass:'oathbound',region:'town'});
  assert(idle.starts.length>idleStarts,'walking has no footsteps');
  const stoppedStarts=idle.starts.length;run(idle,1,{state:'playing',health:1,moving:false,region:'town'});
  assert.equal(idle.starts.length,stoppedStarts,'footsteps continue after stopping');idle.a.dispose();
  const b=setup();b.a.unlock();await settle();run(b,3,{state:'playing',health:.2,combat:true,boss:true,bossHealth:.4});
  const battle=stats(b,1,3);assert.equal(b.a.status().scene,'bellkeeper');assert(battle.rms>calm.rms*1.08);
  b.a.setVolume('effects',0);run(b,2,{state:'paused'});assert.equal(b.a.status().scene,'paused');
  // One representative of every designed cue must produce a finite audible signal.
  const fx=setup();fx.a.unlock();await settle();fx.a.setVolume('music',0);fx.a.setVolume('ambience',0);run(fx,.8);
  const cues=['step','steel','dagger','fire','rend','storm','shadow','nova','evade','heal','hit','hurt','enemyDeath','enemySwing','enemyCast','bossWake','bossCast','bossImpact','bossDeath','sealWake','sealClear','ash','relic','level','objective','thought','equip','ui','heartbeat','death','release','bind','distantBell','fireCrackle','voice'];
  for(const cue of cues) {
    const at=fx.ctx.currentTime;fx.ctx._impl.changeState('running');fx.a.play(cue,{x:120,y:-80},'oathbound');run(fx,6,{state:'paused'});
    const s=stats(fx,at,at+1);assert(s.rms>.00005,cue+' silent');assert(s.peak<.95,cue+' exceeded headroom');
    assert.equal(fx.a.status().activeVoices,0,cue+' did not clean up');
  }
  fx.a.setVolume('voices',0);const silentSpeech=fx.a.status().activeVoices;fx.ctx._impl.changeState('running');fx.a.play('voice',null,{speaker:'Fen'});assert.equal(fx.a.status().activeVoices,silentSpeech,'voice mute ignored');fx.a.setVolume('voices',.5);
  fx.ctx._impl.changeState('running');fx.a.play('steel',{x:2000,y:2000});assert.equal(fx.a.status().activeVoices,0);
  for(let i=0;i<90;i++){fx.ctx._impl.changeState('running');fx.a.play('level');run(fx,.05,{state:'paused'});assert(fx.a.status().activeVoices<=24);assert(fx.a.status().activeSources<=120);}
  run(fx,7,{state:'paused'});assert.equal(fx.a.status().activeVoices,0);
  w.a.toggle();assert(w.a.status().muted);const mutedAt=w.ctx.currentTime;run(w,1);
  assert(stats(w,mutedAt+.6,mutedAt+1).peak<.00001,'master mute did not silence score/ambience');
  const restored=setup({saved:JSON.parse(w.storage.get('determent-audio-v1'))});restored.a.unlock();assert(!restored.a.status().ready,'saved mute ignored');
  w.a.setVolume('music',2);assert.equal(w.a.status().music,1);w.a.setVolume('music',NaN);assert.equal(w.a.status().music,1);
  w.a.toggle();await settle();w.ctx._impl.changeState('running');w.a.setBackground(true);await settle();assert.equal(w.ctx.state,'suspended');
  w.a.setBackground(false);await settle();assert.equal(w.ctx.state,'running');
  const failure=setup({failed:true});failure.a.unlock();await settle();assert(failure.a.status().loadFailed);
  failure.ctx._impl.changeState('running');failure.a.play('steel');assert(failure.a.status().activeVoices>0);
  failure.recover();failure.a.retry();await settle();assert(failure.a.status().musicReady);
  const unsupported=setup({supported:false});unsupported.a.unlock();unsupported.a.play('nova');unsupported.a.update(.1);assert(!unsupported.a.status().supported);
  // Retain a listenable QA rendering of the real mix, rather than just testing mocks.
  fs.writeFileSync('/tmp/determent-audio-qa/battle-render.wav',Buffer.from(await b.ctx.encodeAudioData(b.ctx.exportAsAudioData())));
  [w,b,fx,failure].forEach(x=>x.a.dispose());
  console.log('PASS score decode, 32-second synchronized loops, adaptive mix, '+cues.length+' audible cues, distance attenuation, voice limits/cleanup, mute persistence, background suspension, loading recovery, unsupported browsers');
  console.log('Rendered mix RMS: courtyard '+calm.rms.toFixed(4)+', Bellkeeper '+battle.rms.toFixed(4)+'. Browser reverb/compressor and listening QA remain unverified.');
})().catch(e=>{console.error(e);process.exit(1);});
