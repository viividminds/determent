# Determent — The Ashen Covenant

An original, browser-playable cartoon dark fantasy action RPG. Buildless HTML, CSS, and Canvas 2D; a three-chapter solo campaign with an established safe town, four quest givers and six additional residents, optional quests, class-specific dialogue, and two final conclusions. Deployed to the existing Cloudflare Worker, with static and complete-source export helpers.

## Play

Serve `dist` with a static web server. Choose Oathbound (steel), Cinderborn (fire), or Veilwalker (shadow). Begin in Cinder’s Rest, speak to the townsfolk, then take the northern road. Each chapter has three seals, a guardian, and a resolution. Rest in town between roads. Finish the campaign in the Hollow Spire, then return for NPC epilogues and unfinished side quests.

- WASD or arrows: move in screen directions
- Left click: move or pursue/attack an enemy
- 1: basic attack; Q: class ability; E: ash nova
- Space: evade; R: heal; F: talk, gather, awaken, or travel
- I: inventory; J: journal and side quests; O: objective checklist; M: mute; Esc: pause
- Enter/Space: reveal or advance dialogue; Skip scene or Esc: return to play
- U: town directory and walking routes; T: skills; 2: learned ability; B: market; C: wardrobe; G: road board
- Touch: directional pad, ability/interact buttons, and clickable town destinations

Checkpoints persist in browser localStorage after victories, vows, quest progress, relic pickup, and travel. Old first-chapter checkpoints migrate into the expanded campaign. A new journey replaces the previous save. Returning to town restores health/resolve and at least three flasks; Iven and Fen sell additional flasks for ash. Saves belong to the browser and origin, rather than an online account.

## Campaign & choices

Veyr’s first king chained death to save his daughter. After seven centuries, the dying cannot heal, faces fade from memory, and unwept sorrows become an ocean. A Determent is an exile condemned to carry the kingdom’s final debts. Sister Maelin calls them home.

1. **The Silent Bells · Ashen Courtyard:** free Mercy, Memory, and Mourning; confront the Bellkeeper. Release death or carry his burden. The choice changes later dialogue and the ending’s account of your exile.
2. **The River Without Names · Drowned March:** restore the crossings, retrieve stolen names, and defeat the Drowned Cantor, whose spirit bolts spread across the road.
3. **The Last Dawn · Hollow Spire:** sever Ash, Lament, and Dawn; confront the Knellheart and its overlapping final-phase rune strikes. Restore the cycle or share the last debt. Both choices end the Ashen Covenant and return the exile to the living; there is no unfinished fourth-chapter teaser.

Cinder’s Rest is a safe village with Maelin, Iven the blacksmith, Fen the herbalist, and Orin the ferryman. Each has a personal history, chapter-aware greetings, and post-campaign dialogue. Four side quests include normal enemy/collection work, a difficult optional Hollow Captain encounter, and a class-specific personal debt: free the Oathbound’s last watch, kindle the Cinderborn’s funeral braziers, or recover the Veilwalker’s lost names. Turn in completed work for ash, experience, flasks, and relics. Rewards cannot be claimed twice.

Classes share the main campaign and final choices. They have different combat abilities, voices at major story moments, personal quests/relics, and closing paragraphs, rather than three separate campaigns.

## Sound & atmosphere

The original eight-bar D-minor score uses three synchronized 32-second stems: hushed strings/choir/bells, combat pulses/percussion, and a heavier guardian layer. Layers fade with combat intensity and boss health. Pausing lowers the score; leaving the tab suspends audio. Thirty-five procedural cues cover steel, daggers, fire, shadow, flask, loot, enemy/boss warnings, objectives, endings, and low-health heartbeat. Wind/rain beds, proximity fire/vault sounds, distance attenuation, panning, and chamber reverb add atmosphere. Voice/source limits prevent runaway overlaps.

Sound starts after the first gesture. Use ♫ or **Pause → Sound & atmosphere** for persistent master/music/effects/ambience sliders, mute, calm visuals, and inner-thought controls. Failed score loading leaves effects working and exposes a retry button. Unsupported audio browsers keep the game playable. MP3s are bundled locally. `compose-soundtrack.py` rebuilds the original score using numpy/scipy and ffmpeg; players need none of those tools.

## Visuals & narrative presentation

Bold outlines, flat colors, rounded character silhouettes, and simplified gothic props follow the user’s cartoon references while preserving the original gameplay UI. The village, teal marsh, and slate-purple spire use matching NPC and environment atlases.

Animated flames/sparks, flickering ground light, rain/ripples, fog/ash, moving grass, swaying banners, floating loot, sprite breathing, attack lean, and hit recoil add motion. Steel/rend sparks, fire lances/storms, shadow afterimages/runes, ash shockwaves, and boss warning marks have distinct visuals. Calm visuals and the system’s reduced-motion preference disable shake, flashes, and cinematic drift while reducing weather and particles.

Twelve original illustrated panels accompany dialogue and campaign transitions. They use gentle camera drift, weather overlays, and text reveal; they are still-image scenes rather than fully animated character movies or recorded voice acting. Combat pauses, scenes can be advanced or skipped, and seen-scene state saves. Class/context idle thoughts appear briefly above the exile during quiet moments, disappear near danger, and never pause play.

The HUD and **O** panel describe the chapter’s five goals, highlight the active step, count remaining guardians, and check completed objectives with a chime. **J** tracks side quests, their difficulty, progress, rewards, and turn-in NPCs. Seals can be completed in any order.

## Verification

- `node --check` for all six shipped JavaScript files.
- `node smoke-test.cjs`: all classes, abilities, healing, seals, loot, first guardian, chapter-one choices, recovery, death/revive, Canvas rendering, scene pause/skip, checklist, thoughts, particle limits, and calm motion.
- `node campaign-test.cjs`: all classes; NPC interaction/history; normal, difficult, and personal quests; all three chapters/bosses; choice consequences; both campaign endings; postgame; save restoration; legacy migration; chapter gates; reward idempotency; mute.
- `node audio-test.cjs`: offline waveforms, synchronized score loops, adaptive mixing, all 35 cues, mute persistence, load failure/retry, voice caps/cleanup, background suspension, distance, and unsupported-browser fallback. Dev dependency: `npm install --prefix /tmp/determent-audio-qa web-audio-engine`. First decode shipped MP3s to `/tmp/determent-audio-qa/{covenant,combat,bellkeeper}.wav` using ffmpeg. Its convolver/compressor pass through, so this does not replace browser listening QA.
- `python cloudflare-deploy.py --check-only`: static file and target validation. Official Wrangler dry-run validates the Worker configuration and asset package without deployment.

Smoke/campaign checks use the installed `@napi-rs/canvas` runtime through `test-harness.cjs`; dependencies are development-only. Playwright browser checks exercise desktop and touch navigation, doors, conversation, shops, skills, wardrobe, town contracts, and road travel. Canvas captures and offline signal checks verify rendering and sound scheduling; subjective listening and difficulty balance still benefit from player feedback.

## Cloudflare

`python bundle-cloudflare.py` rebuilds and verifies the dashboard ZIP after updates. Use `--output /workspace/artifacts/determent-cloudflare.zip` to keep downloads outside the public assets. `wrangler.jsonc` and `cloudflare-deploy.py` target `tight-frost-35c6` in the supplied account. Direct updates require the secure execution-environment secret `CLOUDFLARE_API_TOKEN`; no token goes in game assets or source. See [CLOUDFLARE.md](CLOUDFLARE.md) for authentication, deployment, and upload alternatives. Refresh headers revalidate game files without a service worker.

## Transfer to a separate setup chat

`python export-source.py --output /workspace/artifacts/determent-source.zip` creates a complete source archive with assets and Cloudflare helpers, excluding local state and downloaded ZIPs. Attach it when the setup chat has no Sites retrieval tools. See `SOURCE_EXPORT.md` in the archive for restore/validation instructions. `python export-source.py` rebuilds and verifies the export in a Git checkout.

## Homeward lantern update

Orin now offers **The lanterns of the lost** from chapter II onward alongside his difficult Captain quest. Relight three marked lanterns with F, hear the passengers’ illustrated memories and your class’s response, then return to Orin for The Homeward Light. Progress survives travel and reloads, and the quest remains available on the spire road. Older checkpoints receive missing quest defaults without losing completed work. The HUD shows five side quests.

Objectives now identify the current region and remaining seal guardians. The town has quieter rain, the marsh has heavier rain and pale fireflies, and the spire has stronger wind. Idle thoughts acknowledge the safe hearth and postgame life. The existing cartoon art, gothic HUD, original score, three chapters, and both endings remain.

Package without putting downloads in the deployed asset directory:

```sh
python bundle-cloudflare.py --output /workspace/artifacts/determent-cloudflare.zip
python export-source.py --output /workspace/artifacts/determent-source.zip
```

Source export includes imported untracked game files and documentation; staging or committing is not required. Browser saves remain local to their site origin. No Cloudflare deployment is performed by these packaging commands.

## Faceless sketch and conversation update

Human faces are blank wherever skin is exposed; helmets, hoods, beards, and undead skulls retain their silhouettes. All ten artwork sheets now use simple flat colors, clear dark contours, minimal shading, and slightly handmade edges, matching the latest references. Heavy grain, hatching, doubled outlines, and floor flecks have been removed. The gothic HUD composition is unchanged.

NPC dialogue alternates named NPC and class-specific exile replies, including personal-history questions, quest acceptance, and turn-in acknowledgments. Illustrated scenes remain skippable and pause combat.

The recurring idle tapping was addressed by replacing periodically triggered fire-crackle effects with a continuous filtered fire bed. Footsteps are softer and follow actual position changes, including stopping at world boundaries; movement/combat buttons do not also play menu-click sounds. Automated offline tests verify stationary fire starts no repeating transient sources, walking produces footsteps, stopping ends them, and all 35 designed cues produce audible finite waveforms. Browser checks confirm score loading, idle/movement scheduling, dialogue, desktop/touch layout, and absence of page errors. Human listening remains the final check for subjective balance.

## Roads beyond the hearth expansion

The three-chapter Ashen Covenant now has two optional roads, seven town quests, six skill nodes per class, and a learned signature ability. Simple cartoon art, faceless humans, the gothic HUD, and both campaign conclusions carry through the expansion.

- **T — skill tree:** one point per level, including level one; old saves receive their unspent points. Endurance leads through vitality and defense to the signature ability; Power leads through attack, movement/resolve, and class-ability efficiency. Train in town. Paid retraining refunds points without resetting the journey.
- **2 — learned ability:** Oathbound's Bastion break interrupts nearby windups and guards briefly; Cinderborn's Pyre fan launches five fire lances; Veilwalker's Night harvest hits three nearby foes and escapes their reach. All cost resolve and have a cooldown.
- **B — town market:** Iven tempers equipment up to five times, adding four attack each time (60, 120, 180, 240, 300 ash). Fen sells flasks for 20 ash. Upgrades and flask stock are saved.
- **C — wardrobe:** free original, ash, moss, and burgundy outfit palettes with previews. They recolor the existing class sprite; they do not create a separate equipment-slot system or change the class.
- **G — road board:** continue the main covenant or choose a side road. F opens the road board at the northern town gate. Enter the Mended Thread for the tailor and outfit palettes.

**The Cinder Orchard** opens at level 2. Fen's *A season after the fire* asks for three seed vessels left by the king's daughter's gardeners. **Widow's Ossuary** opens at level 3 in chapter II. Maelin's *What we never said* uncovers three hidden letters and the Widow's Keeper. Both use the matching simple cartoon assets, fixed guardian packs, readable interact markers and map markers, remembered lore in the journal, relic turn-ins, and a one-time homeward cache. Cleared guardians, memories and caches remain cleared after reload. Players may recover memories before accepting a quest; acceptance credits their existing discoveries. These roads do not reset main seals, change chapter gates, or replace the ending.

Combat has more durable regular foes, stronger elite strikes, level-scaled chapter boss vitality/damage, and fixed-target windup circles before melee or ranged attacks. Leaving the warning avoids a melee strike; Oathbound's signature interrupts it. Damaging a distant foe activates its pursuit. Stride follows actual movement; strike lean and dodge lean complement the existing effects. Difficulty balance still benefits from human playtesting.

NPC dialogue shows **one turn at a time**, with NPC/exile portraits, current-speaker emphasis, text reveal, Enter/Space or click to reveal/advance, and a skip-to-services option. Story/foe scenes use the same text reveal and procedural voice tones. Speaker pitches differ; these are synthesized syllable-like tones, not recorded narration. The separate **Dialogue voice tones** slider and master mute control them. Tones stop when reveal ends and never run during idle movement.

Checks: `node expansion-test.cjs` covers skill prerequisites/points, unique abilities, cooldowns, shop/palette saves, retraining, attack telegraphs, both road quests/caches, old checkpoints and conversation transitions. Existing smoke/campaign/audio tests also run; the offline audio suite now checks 35 cues including dialogue and voice mute. The browser workflow covers desktop/touch layouts, real skill/market/wardrobe controls, speaker transitions, and road travel.

Later chapter relics now have separate stable IDs so their upgrades are retained alongside first-chapter equipment. Manual equipment selection also saves immediately. Existing inventory is preserved.

## Cinder’s Rest town and simplicity update

A wide valley backdrop frames a walkable town square with six complete buildings, marked entrances, lamps, trees, a well, market furniture, and a ferry landing. Six faceless residents walk between destinations and have short alternating conversations. The main four quest givers still offer all existing quests and class-aware dialogue.

**U** or the Town directory button lists nine destinations and walks the exile around building footprints to the chosen doorway. Press **F** or the on-screen interact button on arrival. Keyboard movement cancels a route. Indoors, use the marked counter or the service shortcut, speak with the owner, and leave through the south doorway. Choosing another destination also returns to the square and starts a walking route.

- **The Last Lantern:** Branna’s inn. Free rest fills vitality and resolve, ensures at least three flasks, and grants +20% XP on the next eight foe defeats. Repeated rest refreshes eight charges without stacking.
- **Chapel of the Bell:** Maelin’s training room and skill tree.
- **Iven’s Forge:** equipment tempering and supplies.
- **Fen’s Apothecary:** flasks, herbs, and Fen’s quests.
- **The Mended Thread:** Nelle’s tailor shop and four outfit palettes.
- **House of Names:** Sera’s archive, town history, and recovered memories.
- **Ferry Landing:** Orin’s conversations and quests.
- **The Notice Tree:** one repeatable contract at a time. Road patrol requires eight foes for 45 ash / 45 XP. The level-3 iron watch requires three brutes, elites, or chapter guardians for 90 ash / 70 XP. Only victories after accepting count. Return to the board to collect; payment is granted once.
- **North Road:** the campaign and two optional roads.

Room selection, rested charges, contract progress, and completed-contract count persist alongside existing checkpoints. Invalid or absent town data safely receives defaults. Room furnishings, warm windows, colored rugs, and sheltered ambience distinguish the interiors. Rain stops indoors; the chapel keeps more chamber resonance.

The original HUD adds a contextual enemy vitality/level panel, nearby-threat count, an XP/unspent-point readout, ability readiness, a short reward feed, and destination guidance. The town sidebar shows places and services; the field keeps its seal checklist. Presentation updates produce no automatic button-click sounds.

`node town-test.cjs` covers all door routes and interiors, rest limits/XP, contract eligibility and payment, checkpoint migration, records, road-board access, idle/walking silence, and real Canvas rendering. All existing smoke, campaign, expansion, and audio regressions also pass. Browser checks cover the actual controls on desktop and touch layouts.

To repeat the real browser town workflow, install Playwright for development, serve `dist`, and run `node town-browser-test.cjs`. Set `DETERMENT_TEST_URL` for a non-default port (default `http://127.0.0.1:8000/`), `CHROMIUM_PATH` for an installed browser, and optionally `DETERMENT_ARTIFACTS` for screenshots. Each test uses a fresh browser context and an isolated local checkpoint.
