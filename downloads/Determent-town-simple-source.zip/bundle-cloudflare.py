#!/usr/bin/env python3
"""Build the dashboard-upload ZIP from the public game files, excluding downloads."""
import argparse
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent / 'dist'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, default=root / 'downloads' / 'determent-cloudflare.zip')
output = parser.parse_args().output
output.parent.mkdir(parents=True, exist_ok=True)
files = [root / name for name in ('index.html', 'style.css', 'campaign.js', 'visuals.js', 'audio.js', 'expansion.js', 'town.js', 'game.js', '_headers')]
files += sorted(p for p in (root / 'assets').rglob('*') if p.is_file())
with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=6) as archive:
    for path in files:
        archive.write(path, path.relative_to(root).as_posix())
with ZipFile(output) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(files)
    for path in files:
        assert archive.read(path.relative_to(root).as_posix()) == path.read_bytes()
print(f'Built and verified {len(files)} files: {output} ({output.stat().st_size:,} bytes)')
