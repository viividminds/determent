function createHarness(){
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const {createCanvas,Image:CanvasImage}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/@napi-rs/canvas');
const els=new Map(),listeners={},storage=new Map();
function el(id){if(els.has(id))return els.get(id);let o=id==='#world'?createCanvas(1280,800):id==='#map'?createCanvas(170,170):{};o.style={};o.dataset={};o.innerHTML='';o.textContent='';const classes=new Set(['#overlay','#hud','#continue'].includes(id)?['hidden']:[]);o.classList={add(...xs){xs.forEach(x=>classes.add(x));},remove(...xs){xs.forEach(x=>classes.delete(x));},contains(x){return classes.has(x);},toggle(x,force){const on=force===undefined?!classes.has(x):force;if(on)classes.add(x);else classes.delete(x);return on;}};o.addEventListener=()=>{};o.focus=()=>{};o.querySelector=()=>null;o.querySelectorAll=()=>[];els.set(id,o);return o;}
class LocalImage extends CanvasImage{set src(v){super.src=__dirname+'/dist/'+v;}get naturalWidth(){return this.width;}}
const sandbox={Image:LocalImage,console,Math,innerWidth:1280,innerHeight:800,devicePixelRatio:1,window:{},document:{querySelector:el,querySelectorAll:()=>[],createElement:()=>createCanvas(1,1),addEventListener:(k,f)=>listeners[k]=f},localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},addEventListener:(k,f)=>listeners['window-'+k]=f,requestAnimationFrame:()=>{}};
vm.runInNewContext(fs.readFileSync(__dirname+'/dist/campaign.js','utf8'),sandbox);
vm.runInNewContext(fs.readFileSync(__dirname+'/dist/visuals.js','utf8'),sandbox);
vm.runInNewContext(fs.readFileSync(__dirname+'/dist/audio.js','utf8'),sandbox);
vm.runInNewContext(fs.readFileSync(__dirname+'/dist/expansion.js','utf8'),sandbox);
vm.runInNewContext(fs.readFileSync(__dirname+'/dist/town.js','utf8'),sandbox);
let code=fs.readFileSync(__dirname+'/dist/game.js','utf8');code=code.replace('window.Determent={','window.__test={start,ability,interact,enterTownBuilding,leaveTownBuilding,townDirectory,goTownPlace,townService,acceptContract,claimContract,restAtInn,readArchives,learnSkill,respecSkills,shopPurchase,setPalette,routeBoard,skillPanel,openWardrobe,renderNPCServices,advanceNPC,update,render,revive,endingChoice,finishEnding,hurt,hitHero,save,inventory,advanceScene,skipScene,objectiveRows,objectives,updateNarrative,travel,nextChapter,talkNPC,acceptQuest,claimQuest,closePanel,journal,hero:()=>hero,game:()=>game,enemies:()=>enemies,loot:()=>loot,sites:()=>({gather:gatherSites,personal:personalSites,elite:eliteSite,watch:watchSite}),hazards:()=>hazards,effects:()=>effects,state:()=>state};window.Determent={');vm.runInNewContext(code,sandbox);
const g=sandbox.window.__test;
const cues=[],actualPlay=sandbox.window.DetermentAudio.play;sandbox.window.DetermentAudio.play=(...args)=>{cues.push(args[0]);actualPlay(...args);};

return {g,els,storage,sandbox,cues,assert,fs,listeners};
}
module.exports={createHarness};
