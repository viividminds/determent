# Restore Determent in the Cloudflare setup checkout

This export contains the existing three-chapter Determent game, original music, cartoon artwork, tests, and Cloudflare deployment helpers. It carries the game source from published Sites revision `ddea2c255ae07aaafc7af7c9720308003cb14c0b`. Archive entries are relative to the project root: `dist/`, `wrangler.jsonc`, and `cloudflare-deploy.py` sit together. Extract them into the setup checkout and replace the placeholder README with this game's README.

The configured target is the existing Worker `tight-frost-35c6`, account `0c4b7b6d3ddd0cad5b4bd90b366fdee0`, at https://tight-frost-35c6.certifiedcoal.workers.dev/.

## Validate during environment setup

With the already installed official Wrangler CLI:

```sh
python cloudflare-deploy.py --check-only
wrangler deploy --dry-run --config wrangler.jsonc --outdir /tmp/determent-worker-dry-run
```

These checks need no API token and perform no deployment. The game is buildless; no npm installation is required for gameplay. `compose-soundtrack.py` and the tests use development dependencies described in README.md, which are unnecessary for uploading the shipped assets.

Save a repeatable install command for Wrangler and startup instructions for this directory. Keep the API credential in the environment's secure Network secrets form:

- Key: `CLOUDFLARE_API_TOKEN`
- Allowed domain: `api.cloudflare.com`
- Token permissions: Workers Scripts: Edit and Account Settings: Read, scoped to the configured account.

Check current environment credential readiness after the user saves/reviews its configuration. A proxy placeholder is expected for a Network secret: use the inherited variable and proxy normally, without reading, logging, or replacing the credential. Complete environment setup and have the user publish it through the environment's controls.

## Deploy once the environment and credential are ready

Run `python cloudflare-deploy.py` (or select the installed CLI with `--wrangler /path/to/wrangler`). It reads authentication only from the inherited environment, verifies the `certifiedcoal` subdomain and existing Worker before writing, and deploys this static game. This replaces the existing game's deployment at the same Worker address. The user has requested that update in the originating conversation. Respect any required environment or tool approval review.

After deployment, report the actual published Worker URL and deployment outcome. Existing browser-local saves remain on that origin. Request future game changes in a task using this published environment.

## Export contents

No Git history, repository access token, API token, environment-secret file, dependency installation, or downloaded ZIP is included. `.openai/hosting.json` contains only the original non-secret Sites project identity; the Cloudflare helper uses `wrangler.jsonc`. If Sites tools become available later, preserve project `appgprj_6acbbbe7b9d881919cadec0c54717852` and its owner-private audience when editing that separate publication.

`python bundle-cloudflare.py` regenerates a dashboard-upload ZIP from the game. `python export-source.py` regenerates this source export in a Git checkout. Generated ZIPs are omitted from exports to avoid recursively bundling downloads.
