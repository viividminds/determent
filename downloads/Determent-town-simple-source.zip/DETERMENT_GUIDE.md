# Determent: guide for helping with the whole game

Use this as the shared brief for future development, troubleshooting, writing, artwork, sound design, and deployment. It describes the current game
and the choices its creator has already made. Read the current code before changing behavior; update this guide when the game changes. The creator's
new instructions take priority over this baseline.

## Start here in another chat

1. Open the existing checkout, or extract `determent-source.zip` into the project root. `dist/`, `wrangler.jsonc`, and `cloudflare-deploy.py` should sit
together.
2. Read `AGENTS.md`, this guide, and `README.md`. Check local changes before syncing or editing. Preserve work already in progress.
3. Establish the requested outcome: a bug fix, a gameplay addition, story/art/audio work, or deployment. Make routine implementation decisions and
carry the work through the applicable checks.
4. Inspect the available environment and tools. A setup chat may lack Sites retrieval tools; the attached source export provides the actual game in that
case. Never treat a placeholder repository README as the complete source.
5. For Cloudflare work, read `CLOUDFLARE.md` and `SOURCE_EXPORT.md`, check current credential readiness, and use the configured target.
Report a live update only after an actual successful deployment.

The source ZIP includes this guide and `AGENTS.md`, so the context travels with the code. `AGENTS.md` gives coding assistants a short entry point.
The dashboard ZIP contains the playable static site; the source ZIP also contains deployment helpers, documentation, and development tools.

## The creator's direction

**Determent — The Ashen Covenant** is an original browser action RPG about a kingdom that imprisoned death and an exile who must settle its
debts. The desired experience combines responsive movement, class abilities, loot, boss fights, and an ornate dark fantasy HUD with a simpler, slightly
cartoonized world.

The creator likes the established gameplay UI. Keep its composition and feel when updating the world art: vitality/resolve orbs, the central ability bar,
quest tracking, minimap, and gothic typography. The supplied reference characters and cathedral set the art direction: thick dark outlines, flat muted
color, rounded helmets/skulls, torn cloaks, simple shading, and strong silhouettes. The atmosphere remains somber and mysterious.

The creator has specifically requested immersive music and effects; moving fire, rain, lighting, and environmental details; distinguishable combat effects;
dialogue/cutscene presentation; occasional idle thoughts; descriptive checklists with completion chimes; more chapters/places/NPCs; normal and
difficult side quests; class-dependent story; a true ending; and updates at the same Cloudflare URL.

Keep content original. Build on familiar action-RPG patterns through Determent's own world, characters, artwork, and score.

## Current playable loop

Choose an exile, begin safely in **Cinder's Rest**, speak to its residents, and accept optional work. Take the northern road into the current chapter.
Awaken three seals in any order, defeat their guardians, face the chapter boss, then approach the northern vow to resolve the chapter. Rest in town
and continue to the next road.

Movement uses WASD/arrows or click-to-move. Clicking an enemy pursues/attacks it. Attacks and abilities provide each class's combat identity. Resolve
regenerates; flasks restore health; ash and relics provide progression; stronger relics increase attack. Leveling restores vitality. Town restores
health/resolve and at least three flasks, and its merchants sell additional flasks for ash.

| Control | Action |
| --- | --- |
| WASD / arrows | Move in screen directions |
| Left click | Move or pursue/attack an enemy |
| 1 | Basic attack |
| Q | Class ability |
| E | Ash nova |
| Space | Evade; brief invulnerability |
| R | Healing flask |
| F | Talk, gather, awaken, resolve, or travel |
| I / J / O | Inventory / journal and side quests / objective checklist |
| M / Esc | Mute / pause or close a panel |
| Enter / Space in dialogue | Reveal or advance the line |
| Touch controls | Directional pad and ability/interact buttons |

Scenes pause combat and can be skipped. Idle thoughts never pause play. Boss ground warnings must remain readable beneath lighting and particles.
Cinder's Rest stays safe, giving the player a place to listen, recover, and understand the next goal.

## Story and character reference

For seven centuries, Veyr has lived beneath silent bells. Its first king chained death to save his daughter, binding the bargain with mercy, memory, and
mourning. The dying linger without healing, names survive while faces fade, and unwept grief becomes an ocean beneath the cathedral. The dead rise

carrying the living's unfinished promises.

A **Determent** is an exile condemned to bear those final debts. Sister Maelin, the last bell-ringer, calls the exile home. The story asks when a promise
becomes a prison, whether protection can allow an ending, and how grief can be shared rather than imposed on one person.

Write grounded, brief dialogue that sounds like people trying to live with the curse. Let objects, work, and relationships carry meaning: a hammer, a
ferry token, a funeral ember, a bell rope. Maelin is compassionate and determined; Iven turns inherited grief into useful work; Fen speaks plainly about
care and natural cycles; Orin hides his loss behind a ferryman's practical concerns.

### Chapters

| Chapter | Place and seals | Boss | Resolution |
| --- | --- | --- | --- |
| I: The Silent Bells | Ashen Courtyard; Mercy, Memory, Mourning | The Bellkeeper, the first king | Release death or carry the covenant's burden |
| II: The River Without Names | Drowned March; Last light, Lost names, The ferry toll | The Drowned Cantor | Return stolen names and free the
crossing |
| III: The Last Dawn | Hollow Spire; Ash, Lament, Dawn | The Knellheart | Restore the cycle or share the final debt |

The chapter-I choice changes later NPC dialogue and the final account of the exile's burden. The Cantor adds spreading spirit bolts; the Knellheart's
final phase creates multiple rune hazards. The third chapter resolves the Ashen Covenant. Both conclusions return the exile to the living and support a
postgame town epilogue and unfinished side quests.

When adding story, connect it to existing people, locations, and consequences. Preserve the campaign's conclusion unless the creator requests a
different structure. Additional content can be a side story, a chapter inserted into the journey, or a clearly defined expansion after the original ending;
update progression, dialogue, checkpoints, and endings together.

### Classes

| Class | Combat and story identity | Personal quest | Reward |
| --- | --- | --- | --- |
| Oathbound | Steel, close combat, Grave rend; learns an oath can protect life while allowing it to end | A sentinel's last watch: free three
oathbreakers | Shield of the Unforgotten |
| Cinderborn | Fire, ranged combat, Cinder storm; learns a flame can remember and warm without imprisoning | A flame worth keeping: kindle three
braziers, 20 resolve each | The Kindling Covenant |
| Veilwalker | Shadow, swift combat, Veil strike; returns names to the living and finds a home | Names in the dark: recover three tablets whose
watchers awaken | The Names We Carry |

The classes currently share the main chapter structure. Their abilities, important dialogue lines, personal quests/relics, and epilogues differ. Describe that
accurately when discussing class-dependent story. New class branches should have consequences visible in the journey, not just a different title.

### Town residents and optional work

| NPC | Work | Quest |
| --- | --- | --- |
| Sister Maelin | Bell-ringer and guide | The selected class's personal debt |
| Iven | Blacksmith; sells flasks | A debt of iron: defeat eight enemies; normal difficulty |
| Fen | Herbalist; sells flasks | A hand for the living: gather three moonwort patches; normal difficulty |
| Orin | Ferryman | The captain without a shore: defeat the optional Hollow Captain; difficult, recommended level 3 |

Each resident has a personal-history topic, chapter-aware greetings, and post-campaign dialogue. Quest states are `available → active → ready →
claimed`. Work is completed in the field and turned in to the town NPC. Reward granting must remain idempotent. **J** shows descriptions,
difficulty, progress, rewards, and the return destination.

## Art, atmosphere, and presentation

Use cold stone/teal/slate surroundings, muted moss and burgundy, pale bone/steel, and warm amber flame. Preserve clear silhouettes at gameplay
scale. Each place should feel different: a warm village hearth, wet teal marsh and crossings, and a colder slate-purple spire.

The current environment has procedural flames/sparks, flickering pools of light, rain and puddle ripples, drifting fog/ash, grass and banner movement,
floating loot, sprite breathing/sway, attack lean, and hit recoil. Combat distinguishes steel/rend sparks, daggers, fire lances/storms, shadow
afterimages/runes, ash waves, healing, and enemy/boss warnings.

Twelve illustrated panels support scenes using slow camera drift, atmospheric overlays, and text reveal. These are illustrated still-image scenes; fully
animated character cinematics and recorded voice acting are future work. Scene text must remain readable, keyboard accessible, and skippable. Calm
visuals honor the system's reduced-motion preference and disable shake/flashes/cinematic drift while reducing particles and weather.

Idle thoughts are short class/context quotes above the exile during quiet moments. They hide near danger, have cooldowns, and can be disabled. Use
them for a small observation or emotional response, not required instructions that a moving player might miss.

### Asset handling

| Asset | Purpose |
| --- | --- |
| `dist/assets/characters-simple.png` | Original six character designs; renderer uses explicit source rectangles |
| `dist/assets/scenery-simple.png` | Gothic environment props |
| `dist/assets/cathedral-simple.png` | Illustrated title background |
| `dist/assets/villagers.png` | Town residents, Hollow Captain, Drowned Cantor; three columns by two rows |
| `dist/assets/region-props.png` | Cottage, smith stall, willow, dock, ritual stone, campfire; three columns by two rows |
| `dist/assets/covenant-scenes.png` | First six scene panels; two columns by three rows |
| `dist/assets/journey-scenes.png` | Six additional panoramic panels; two columns by three rows |

The two scene sheets have different panel aspect ratios. CSS currently uses `9/4` for covenant panels and `3.375` for journey panels. Inspect
dimensions, transparency, crop rectangles, and CSS background positioning when replacing art. Preserve atlas ordering or update every consumer. Keep
required images local to the static bundle and avoid baked-in dialogue text.

## Sound design

The score is original: an eight-bar D-minor motif with synchronized 32-second covenant, combat, and guardian stems. The base layer uses hushed
strings, choir-like tones, plucked notes, and bells. Combat and boss pressure add percussion/pulses. Layers stay in phase and fade with intensity instead
of restarting on every enemy.

`audio.js` adds 34 procedural cues, wind/rain beds, proximity fire, chamber ambience, distance attenuation, panning, and reverb. Steel, daggers, fire,
shadow, healing, loot, objectives, and boss warnings should remain recognizable in a busy encounter. Keep completion cues satisfying but brief; avoid
allowing music or environmental rumble to obscure danger signals.

Audio starts after a player gesture. Persistent master/music/effects/ambience sliders, mute, background suspension, and load retry are implemented. A
music load failure leaves effects usable; unsupported audio leaves gameplay usable. Preserve source/voice cleanup and the existing bounds. The offline
test verifies at most 24 active voices and 120 active sources under its stress case.

Shipped MP3s live in `dist/assets/audio/`. `compose-soundtrack.py` rebuilds them with numpy, scipy, and ffmpeg. Keep loop duration/alignment and
headroom consistent when adding stems. Browser listening is required for final judgement of balance, reverb, compression, and loop seams.

## Code map

The runtime is buildless HTML/CSS/JavaScript and Canvas 2D. There is no game backend or player account system. Script order in `dist/index.html` is
campaign, visuals, audio, then game.

| File | Responsibility |
| --- | --- |
| `dist/index.html` | Title screen, HUD, controls, overlays, script loading |
| `dist/style.css` | Existing UI, responsive panels, scene presentation, reduced motion |
| `dist/campaign.js` | Chapter/NPC/quest data, class voices, personal stories and dialogue |
| `dist/game.js` | Main state, input, combat, rewards, saving, interaction, scenes, travel, rendering |
| `dist/visuals.js` | Particle/ring emitters, fire/weather, impact/screen effects, calm mode |
| `dist/audio.js` | Audio unlock, score loading/mixing, procedural cues, ambience and saved mix |
| `dist/_headers` | Refresh revalidation and MIME sniffing protection for Cloudflare |
| `test-harness.cjs` | Fake DOM/localStorage plus real Canvas for deterministic game checks |
| `smoke-test.cjs` / `campaign-test.cjs` | Core gameplay and full campaign checks |
| `audio-test.cjs` | Offline rendering and sound behavior checks |
| `bundle-cloudflare.py` | Build/verify the dashboard game ZIP |
| `export-source.py` | Build/verify source export; exclude downloads/local credentials |
| `cloudflare-deploy.py` / `wrangler.jsonc` | Verify the existing account/Worker, then deploy static assets |

`game.js` uses a closure around `hero`, `game`, enemies, props, effects, and interaction helpers. Campaign data is exposed as `DetermentCampaign`;
audio and visuals expose their own APIs. `window.Determent.getState()` is a read-only diagnostic surface. The test harness injects private test helpers
into its in-memory source; never ship those mutation helpers to players.

When adding a quest, update its data, interaction/progress logic, world markers, journal/HUD text, rewards, and saved state. When adding a chapter,
update chapter data, region art/population, seals and guardian, scenes, navigation gates, all later dialogue and endings, and migration. Some UI counts
and three-chapter arrays are currently explicit; search all consumers rather than assuming data alone extends the campaign.

## Saves and compatibility

| Storage key | Purpose |
| --- | --- |
| `determent-v1` | Class, level/XP, ash, relics/equipment, chapter/region, seals, choices, campaign completion, quests, gathered sites, scene/thought
history |
| `determent-audio-v1` | Saved audio mix and mute |
| `determent-visuals-v1` | Calm-visual preference |
| `determent-thoughts` | Inner-thought preference |

Saves belong to the browser and origin. Moving from Sites to Cloudflare creates a separate storage context; updating the same Worker URL retains it.
New Journey replaces the checkpoint. Legacy first-chapter saves have defaults for campaign fields.

Preserve stable quest/item/scene IDs and compatible defaults. A checkpoint restores progression and a healthy hero, rather than serializing every
current enemy, hazard, or exact combat position. Travel/revive recreate field populations. Test leaving and re-entering a spawned boss, resuming a
completed chapter, and returning after the ending. Save progress/rewards after the relevant state and XP updates to avoid mismatched recovery.

## Verification and issue diagnosis

Run checks appropriate to the change:

| Change | Useful checks |
| --- | --- |
| Combat, input, travel, saving, UI behavior | Script syntax; smoke checks; campaign checks if progression is affected |
| Quests, dialogue branches, chapters, ending | Campaign checks across all classes/choices; inspect updated scene/checklist text |
| Art, effects, scene layout | Syntax where applicable; Canvas captures; supported browser checks at desktop/touch sizes |
| Audio code or score | Audio offline checks; decode updated MP3s first; browser listening when available |
| Deployment config/assets | `python cloudflare-deploy.py --check-only`; official Wrangler dry-run |
| Documentation/export | Verify documents exist in the ZIP, integrity/content matches, and clean extraction validates |

Basic commands from the project root:

```sh
node --check dist/campaign.js
node --check dist/visuals.js
node --check dist/audio.js
node --check dist/game.js
node smoke-test.cjs
node campaign-test.cjs
python cloudflare-deploy.py --check-only
```

The Canvas harness currently references an installed `@napi-rs/canvas` package through a managed-runtime path. A different environment may need
that development dependency and adjusted resolution. `audio-test.cjs` expects `web-audio-engine` under `/tmp/determent-audio-
qa/node_modules/` and decoded WAVs in the same folder; README.md documents setup. These tools are unnecessary for running/deploying the
shipped game.

The current gameplay/campaign tests use deterministic shortcuts to exercise paths; they do not establish difficulty balance or sustained human
playability. Offline audio passes through its convolver/compressor, so it does not verify their browser sound. Previous checks passed, but live
browser/listening QA was unavailable. State those limits accurately. Follow the active environment's supported browser workflow and any applicable
Sites skill restrictions.

For a report of silence, check the first-gesture unlock, M mute, channel levels, MP3 requests, retry state, and tab suspension. For blocked progress,
inspect region/chapter, seal state, current enemies, quest status, dialogue pause, and northern-vow interaction range. For stale code, check the
deployment result and refresh headers before diagnosing gameplay. For a missing boss after travel, inspect `loadRegionPopulation()` and boss flags.
For duplicate rewards, inspect the `ready → claimed` transition and checkpoint.

## Deployment and source transfer

| Target | Identity and behavior |
| --- | --- |
| Existing Cloudflare game | Worker `tight-frost-35c6`; account `0c4b7b6d3ddd0cad5b4bd90b366fdee0`; https://tight-frost-
35c6.certifiedcoal.workers.dev/ |
| Existing private Sites game | Project `appgprj_6acbbbe7b9d881919cadec0c54717852`; https://determent.daringbuddy6.chatgpt.site |

The account ID and project ID are non-secret. `CLOUDFLARE_API_TOKEN` is a deployment credential. It belongs in the execution environment's
secure Network secrets form, with `api.cloudflare.com` allowed. Keep it out of game code, archives, chat, command arguments, and logs. Use
configured proxy substitution normally; a placeholder does not mean the binding is absent. Verify current readiness and then actual API authorization.

The Cloudflare helper checks the account's `certifiedcoal` subdomain and existing Worker before writing. Use the official Wrangler CLI. `_headers`
asks browsers to revalidate files on refresh; no service worker caches a stale release. Requested updates can retain the same URL. This is a workflow for
requested updates, not an unattended updater.

```sh
python bundle-cloudflare.py
python cloudflare-deploy.py --check-only
wrangler deploy --dry-run --config wrangler.jsonc --outdir /tmp/determent-worker-dry-run
# Once deployment is authorized and the configured credential is ready:
python cloudflare-deploy.py

```

Rebuild the source ZIP after source/document changes with `python export-source.py`. It uses tracked files plus the guide entry points and omits
`dist/downloads/`, local state, and credentials. Newly added source files must be included in the export's file selection. Maintain
`SOURCE_EXPORT.md` as the restore instructions.

When Sites tools are available, follow the Sites skill to retrieve/synchronize its source, commit/push/package the exact revision, and publish through the
native tool. Preserve its owner-private audience. When a setup chat lacks those tools, download the source ZIP from the existing Site and attach it
there. Extract, validate, complete environment setup, and publish the environment through its UI before starting a task in it. A published environment
and a published game are separate outcomes.

### Status at guide creation: October 11, 2026

The expanded three-chapter game and source export are published through the existing private Site. The separate setup chat reported official Wrangler
4.149.0 installed and a secure token requirement prepared; it needed the source export because Sites tools were unavailable. No successful deployment
to the user's Worker has been reported. This originating session still has no Cloudflare credential configured. Recheck these facts in the current
environment rather than treating this dated status as a permanent blocker.

## Finish an update well

Explain the resulting player experience and relevant checks, identify any remaining verification limit, and give the actual confirmed play/download
URL. Keep this guide, README, and exports consistent with the implementation. If authentication blocks deployment, complete the implementation
and package anyway, then identify the exact remaining configuration step. Avoid rebuilding the game or changing its hosting identity just because a
new chat has less context.

A useful handoff prompt is: **“Read AGENTS.md and DETERMENT_GUIDE.md in the attached Determent source. Continue the existing game with
[requested change], preserve its cartoon dark fantasy direction and saves, run the relevant checks, and update its authorized existing deployment when
credentials are ready.”**


## Local update: Homeward lanterns

See README.md for the new Orin lantern quest, five-quest HUD, save-default migration, chapter-aware objectives, and regional atmosphere. The account token was verified by read-only API checks in this environment; no game deployment has occurred. This dated observation must be rechecked before publishing. Source exports now include imported source even when untracked.

## Faceless sketch and conversation update

See README.md for the new faceless-human art treatment across sprites and scenes, simple flat cartoon colors and light handmade contours, alternating class-aware NPC conversation, and continuous-fire/soft-footstep audio fix. Keep facial features absent on exposed living human faces in future assets; retain skull features and covered faces. Preserve the gothic HUD.

## Roads beyond the hearth expansion

The current implementation adds `dist/expansion.js`, loaded after audio and before game. It owns the six-node class trees, signature definitions, palette choices, optional road/quest/scene data, and point normalization. `game.js` connects training, commerce, wardrobe, fixed-target enemy windups, road populations, and single-turn NPC dialogue. Existing saves gain missing `skills`, `upgrades`, `palette`, `expeditions`, and new quest defaults; flask stock is also retained. Skill points are earned by level, rather than saved as an independent counter.

Read the README expansion section for controls, gates, prices, content and validation. Preserve the campaign's original three-chapter conclusion. The Cinder Orchard and Widow's Ossuary are optional side stories with a total of six recoverable memories, two additional quests, one mini-boss confrontation, and per-road one-time caches. Fen and Maelin acknowledge the completed work. These maps use the matching simple cartoon atlases and illustrated panels.

NPCs use one spoken turn and current-speaker portraits instead of the previous transcript panel. Procedural voice tones have an independent saved mix slider. Keep tones coupled to text reveal so the previous idle-tapping problem cannot return. Use `expansion-test.cjs`, existing regression suites, and desktop/touch browser checks for future changes. Automated tests establish progression and scheduling, not final human difficulty or listening balance.

## Cinder’s Rest town update

The current town has six walkable interiors, a wide valley backdrop, six roaming residents alongside the four quest givers, nine navigable destinations, rested experience, and two repeatable road contracts. Read the README town section for destinations, controls, reward amounts, save behavior, and verification. Keep art close to the supplied simple reference sheets: bold dark outlines, flat muted colors, restrained shadows, faceless exposed human faces, and very little surface texture. Preserve the original gothic HUD while making progression, targets, rewards, and town navigation easier to read.

`dist/town.js` owns building destinations, resident dialogue/routes, town drawing helpers, pathfinding, and contract definitions. `dist/game.js` connects them to doors, room services, combat rewards, checkpoints, and the HUD. Add this module to every source/bundle validation when packaging.
