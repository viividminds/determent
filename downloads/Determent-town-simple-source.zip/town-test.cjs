const {createHarness}=require('./test-harness.cjs');
const {g,els,storage,sandbox,assert,cues,listeners}=createHarness();
const T=sandbox.window.DetermentTown;
const tick=(seconds=1)=>{for(let i=0;i<seconds/0.016;i++)g.update(.016);};
const settle=()=>{g.skipScene();g.closePanel();};
const at=p=>Object.assign(g.hero(),{x:p.x,y:p.y});
setTimeout(()=>{
 g.start('oathbound',{klass:'oathbound',level:4,gold:300,scenesSeen:['arrival']});
 const first=T.people(0),later=T.people(4);
 assert(first.some((v,i)=>Math.hypot(v.x-later[i].x,v.y-later[i].y)>10),'residents never walk');
 for(const site of T.sites){
  g.goTownPlace(site.id);tick(15);assert(Math.hypot(g.hero().x-site.door.x,g.hero().y-site.door.y)<15,'navigation failed: '+site.id);
  assert(!T.blocked(g.hero().x,g.hero().y));g.interact();assert.equal(g.game().interior,site.id);assert.equal(g.enemies().length,0);g.render(.016);
  assert(els.get('#quest-list').innerHTML.includes('data-town-service'));
  at({x:0,y:185});g.interact();assert.equal(g.game().interior,null);assert(Math.hypot(g.hero().x-site.door.x,g.hero().y-site.door.y)<30);
 }
 console.log('PASS six walkable doorways, pathfinding around buildings, distinct safe interiors, services and physical exits');
 g.enterTownBuilding('inn');g.hero().hp=15;g.hero().resolve=5;g.hero().flasks=0;g.restAtInn();assert.equal(g.hero().hp,g.hero().maxHp);assert.equal(g.hero().resolve,100);assert.equal(g.hero().flasks,3);assert.equal(g.game().restedCharges,8);
 g.restAtInn();assert.equal(g.game().restedCharges,8,'rested bonus stacks without limit');g.closePanel();g.save();const save=JSON.parse(storage.get('determent-v1'));g.start('oathbound',save);assert.equal(g.game().interior,'inn');assert.equal(g.game().restedCharges,8);g.leaveTownBuilding();
 g.acceptContract('patrol');assert.equal(g.game().contract.progress,0);g.acceptContract('armored');assert.equal(g.game().contract.kind,'patrol','second contract replaced first');g.closePanel();g.travel('field');g.skipScene();at({x:-290,y:-260});g.interact();
 const foe=g.enemies()[0],beforeXP=g.hero().xp;Object.assign(foe,{x:g.hero().x+100,y:g.hero().y,active:true});g.hero().aim=foe;g.update(.016);assert(!els.get('#target-hud').classList.contains('hidden'));assert(els.get('#target-detail').textContent.includes('VITALITY'));g.hurt(foe,9999);assert.equal(g.game().restedCharges,7);assert.equal(g.hero().xp-beforeXP,18,'rested foe XP should be rounded +20%');assert.equal(g.game().contract.progress,1);g.hurt(foe,9999);assert.equal(g.game().contract.progress,1,'dead foe counted twice');g.update(.016);assert(els.get('#reward-feed').innerHTML.includes('EXPERIENCE'));
 for(const e of g.enemies().slice())g.hurt(e,9999);g.update(.016);assert.equal(g.game().contract.progress,8);assert.equal(g.game().restedCharges,0);g.travel('town');g.closePanel();const ash=g.hero().gold;g.claimContract();assert.equal(g.hero().gold,ash+45);assert.equal(g.game().contractsCompleted,1);g.claimContract();assert.equal(g.hero().gold,ash+45,'contract paid twice');g.closePanel();
 g.acceptContract('armored');g.closePanel();g.travel('orchard');g.skipScene();const hollow=g.enemies().find(e=>e.type==='cantor');g.hurt(hollow,9999);assert.equal(g.game().contract.progress,0,'ranged foe credited armored contract');for(const e of g.enemies().filter(e=>e.type==='brute'))g.hurt(e,9999);assert.equal(g.game().contract.progress,3);g.save();assert.equal(JSON.parse(storage.get('determent-v1')).contract.progress,3);
 console.log('PASS interior checkpoint migration, non-stacking rest and flask refill, bounded rested XP, patrol/armored eligibility, persistence and one-time payment');
 g.travel('town');settle();g.goTownPlace('board');tick(12);g.interact();assert(els.get('#panel').innerHTML.includes('Collect 90 ash'));g.closePanel();g.goTownPlace('gate');tick(12);g.interact();assert(els.get('#panel').innerHTML.includes('Beyond the hearth'));g.closePanel();
 g.enterTownBuilding('archives');g.readArchives();assert(els.get('#panel').innerHTML.includes('A town made of small things'));g.closePanel();g.leaveTownBuilding();
 at({x:0,y:70});cues.length=0;tick(6);assert(!cues.includes('ui'),'idle town produces button cues');listeners['window-keydown']({key:'s',target:{tagName:'BODY'},preventDefault(){}});tick(2);listeners['window-keyup']({key:'s'});assert(!cues.includes('ui'),'walking produces button cues');
 g.start('veilwalker',{klass:'veilwalker',region:'town',interior:'missing',restedCharges:200,contract:{kind:'invalid'},scenesSeen:['arrival']});assert.equal(g.game().interior,null);assert.equal(g.game().restedCharges,8);assert.equal(g.game().contract,null);g.render(.016);
 console.log('PASS notice board, road board, archives, idle/walking silence, invalid saved town-state handling, and Canvas rendering');
},200);
