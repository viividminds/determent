const {createHarness}=require('./test-harness.cjs');
const {g,els,storage,sandbox,cues,assert,fs,listeners}=createHarness();
const C=sandbox.window.DetermentCampaign;
function click(data){listeners.click({target:{closest:()=>({dataset:data,hasAttribute:()=>false})}});if(data.acceptQuest||data.claimQuest)g.skipScene();}
function skip(){g.skipScene();}
function at(site){g.hero().x=site.x;g.hero().y=site.y;}
function clearChapter(klass){
  for(let i=0;i<3;i++){
    at({x:[-290,320,70][i],y:[-260,-210,345][i]});g.interact();assert.equal(g.game().activeSeal,i);
    for(const e of g.enemies().slice())g.hurt(e,99999);g.update(.016);assert.equal(g.state(),'paused');skip();
    assert(g.game().seals[i]);const relic=g.loot().find(l=>l.type==='relic');if(relic){at(relic);g.update(.016);}
  }
  const boss=g.enemies().find(e=>e.boss);assert(boss);assert(boss.maxHp>=C.chapter(g.game().chapter).hp);if(g.hero().level>1)assert(boss.maxHp>C.chapter(g.game().chapter).hp,'boss did not scale with level');
  at({x:boss.x+35,y:boss.y+35});g.update(.016);skip();
  g.hero().resolve=100;g.hero().cool.special=0;const hp=boss.hp;g.ability('special');assert(boss.hp<hp,klass+' special did not damage chapter '+g.game().chapter+' boss');
  if(g.game().chapter===2){boss.cd=0;g.update(.016);g.update(.65);assert(g.effects().filter(e=>e.type==='bolt'&&!e.friendly).length>=3,'Cantor fan missing');}
  if(g.game().chapter===3){boss.hp=boss.maxHp*.4;boss.spell=0;g.update(.016);assert(g.hazards().length>=4,'Knellheart final phase missing');}
  g.render(.1);fs.writeFileSync('/tmp/determent-chapter-'+g.game().chapter+'.png',els.get('#world').toBuffer('image/png'));
  g.hurt(boss,99999);g.update(.016);assert(g.game().bossDefeated);
  const relic=g.loot().find(l=>l.type==='relic');if(relic){at(relic);g.update(.016);}
  at({x:0,y:-450});g.interact();assert.equal(g.state(),'ending');
}
setTimeout(()=>{
 for(const [klass,firstChoice] of [['oathbound','release'],['cinderborn','bind'],['veilwalker','release']]){
  g.start(klass);assert.equal(g.game().region,'town');assert.equal(g.enemies().length,0);skip();
  g.acceptQuest('lanterns');assert.equal(g.game().sideQuests.lanterns.status,'available','chapter gate for lantern quest bypassed');
  const chapter=g.game().chapter;g.nextChapter();assert.equal(g.game().chapter,chapter,'chapter gate bypassed');
  g.render(.2);if(klass==='oathbound')fs.writeFileSync('/tmp/determent-town.png',els.get('#world').toBuffer('image/png'));
  for(const n of C.npcs){at(n);g.interact();assert.equal(g.state(),'paused');assert(els.get('#panel').innerHTML.includes(n.name));assert(els.get('#panel').innerHTML.includes('conversation-stage'));assert(!els.get('#panel').innerHTML.includes('conversation-lines'));g.advanceScene();g.advanceScene();assert(els.get('#panel').innerHTML.includes('YOUR EXILE'));assert.equal(C.conversation(n.id,g.game(),false).length,3);g.talkNPC(n.id,true);g.advanceScene();g.advanceScene();assert(els.get('#panel').innerHTML.includes(C.topics[n.id]));g.skipScene();click({acceptQuest:n.quest});assert.equal(g.game().sideQuests[n.quest].status,'active');g.closePanel();}
  g.talkNPC('maelin');for(let turn=0;turn<4;turn++)g.advanceScene();assert(els.get('#panel').innerHTML.includes(C.personal[klass].opening));g.skipScene();g.closePanel();
  g.travel('field');for(const e of g.enemies().slice())g.hurt(e,99999);g.update(.016);
  for(const site of g.sites().gather){at(site);g.interact();}assert.equal(g.game().sideQuests.herbs.status,'ready');
  if(klass==='oathbound'){at(g.sites().watch);g.interact();assert.equal(g.enemies().filter(e=>e.personalGuard).length,3);for(const e of g.enemies().filter(e=>e.personalGuard))g.hurt(e,99999);}
  else{g.hero().resolve=100;for(const site of g.sites().personal){at(site);g.interact();}}
  assert.equal(g.game().sideQuests.personal.status,'ready');
  for(const e of g.enemies().filter(e=>e.hp>0))g.hurt(e,99999);g.update(.016);
  at(g.sites().elite);g.interact();const captain=g.enemies().find(e=>e.sideElite);assert(captain&&captain.maxHp===340);g.hurt(captain,99999);g.update(.016);
  assert.equal(g.game().sideQuests.iron.status,'ready');assert.equal(g.game().sideQuests.elite.status,'ready');
  g.travel('town');for(const id of Object.keys(C.quests).filter(id=>!C.quests[id].minChapter&&!C.quests[id].minLevel)){click({claimQuest:id});assert.equal(g.game().sideQuests[id].status,'claimed');const ash=g.hero().gold;g.claimQuest(id);assert.equal(g.hero().gold,ash,'duplicate reward');g.closePanel();}
  assert(g.hero().inventory.some(i=>i.name===C.personal[klass].relic));g.journal();assert(els.get('#panel').innerHTML.includes(C.personal[klass].title));g.closePanel();
  // Travel does not lose main progression, and returning to a spawned boss recreates it.
  g.travel('field');clearChapter(klass);g.finishEnding(firstChoice);skip();assert(!g.game().campaignComplete);assert.equal(g.game().covenant,firstChoice);g.nextChapter();assert.equal(g.game().chapter,2);assert.equal(g.game().region,'town');
  const afterChoice=C.dialogue('maelin',g.game()).line;assert(afterChoice.includes(firstChoice==='release'?'returned death':'covenant beats'));
  g.acceptQuest('lanterns');assert.equal(g.game().sideQuests.lanterns.status,'active');g.skipScene();g.closePanel();
  g.travel('field');skip();
  for(const [i,l] of C.lanterns.entries()){
   at(l);g.interact();assert.equal(g.game().sideQuests.lanterns.progress,i+1);assert.equal(g.state(),'paused');
   assert(els.get('#panel').innerHTML.includes(l.name));g.advanceScene();g.advanceScene();
   assert(els.get('#panel').innerHTML.includes(C.lanternVoices[klass]));skip();
   g.interact();assert.equal(g.game().sideQuests.lanterns.progress,i+1,'duplicate lantern credit');
   if(i===0){g.save();const checkpoint=JSON.parse(storage.get('determent-v1'));g.start(klass,checkpoint);assert.equal(g.game().sideQuests.lanterns.progress,1);assert(g.game().gathered.includes(l.id));}
  }
  assert.equal(g.game().sideQuests.lanterns.status,'ready');g.travel('town');g.claimQuest('lanterns');g.skipScene();
  assert(g.hero().inventory.some(v=>v.name==='The Homeward Light'));const lanternAsh=g.hero().gold;g.claimQuest('lanterns');assert.equal(g.hero().gold,lanternAsh);
  assert(els.get('#panel').innerHTML.includes('Mara. Tovin. Elian.'));g.closePanel();
  g.travel('field');skip();clearChapter(klass);skip();assert(g.game().finished);assert(!g.game().campaignComplete);g.nextChapter();assert.equal(g.game().chapter,3);
  g.travel('field');skip();clearChapter(klass);assert(els.get('#panel').innerHTML.includes('Who owns the morning?'));
  for(const finalChoice of ['release','bind']){g.finishEnding(finalChoice);skip();assert(g.game().campaignComplete);assert.equal(g.game().finalChoice,finalChoice);assert(els.get('#panel').innerHTML.includes('The Ashen Covenant is ended.'));assert(els.get('#panel').innerHTML.includes(C.personal[klass].relic));}
  const ids=g.hero().inventory.map(i=>i.id);assert.equal(new Set(ids).size,ids.length,'chapter relic IDs collide');assert(ids.includes('relic-2-3')&&ids.includes('relic-3-3'),'later chapter relics were lost');
  assert.equal(JSON.stringify(g.game().chaptersCleared),JSON.stringify([1,2,3]));g.nextChapter();assert.equal(g.game().chapter,3);
  g.travel('town');assert.equal(g.enemies().length,0);g.talkNPC('iven');assert(els.get('#panel').innerHTML.includes('hinges instead of swords'));g.closePanel();
  g.save();const saved=JSON.parse(storage.get('determent-v1'));g.start(klass,saved);assert(g.game().campaignComplete);assert.equal(g.game().chapter,3);assert.equal(g.game().region,'town');assert(g.objectiveRows().every(r=>r.done));assert(Object.keys(C.quests).filter(id=>!C.quests[id].minLevel).every(id=>g.game().sideQuests[id].status==='claimed'));
  console.log('PASS '+klass+': four NPCs and lore topics, normal/elite/personal quests, turn-in rewards, three chapters and bosses, covenant consequences, both final endings, postgame town and checkpoint restoration');
 }
 // Existing first-chapter saves remain usable with new campaign fields.
 g.start('oathbound',{klass:'oathbound',level:2,xp:0,gold:5,seals:[true,false,false],inventory:[{id:'starter',power:0,rarity:'common',name:'Exile’s blade',icon:'⚔',desc:'old save'}],equipped:'starter'});skip();assert.equal(g.game().chapter,1);assert(g.game().seals[0]);assert.equal(g.game().sideQuests.iron.status,'available');assert.equal(g.hero().level,2);
 const audio=sandbox.window.DetermentAudio;const oldMute=audio.status().muted;listeners['window-keydown']({key:'m',preventDefault(){}});assert.notEqual(audio.status().muted,oldMute);
 const partial={klass:'oathbound',sideQuests:{iron:{status:'claimed',progress:8}}};g.start('oathbound',partial);assert.equal(g.game().sideQuests.iron.status,'claimed');assert.equal(g.game().sideQuests.lanterns.status,'available');assert.equal(g.game().sideQuests.herbs.status,'available');
 console.log('PASS legacy checkpoint migration, chapter gates, class-dependent dialogue, quest reward idempotency, and mute keyboard binding');
},150);
