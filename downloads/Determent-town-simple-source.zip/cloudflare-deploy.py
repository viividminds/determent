#!/usr/bin/env python3
"""Deploy the static game to the user's existing Worker using environment-only auth."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent
ACCOUNT = '0c4b7b6d3ddd0cad5b4bd90b366fdee0'
WORKER = 'tight-frost-35c6'
SUBDOMAIN = 'certifiedcoal'
URL = f'https://{WORKER}.{SUBDOMAIN}.workers.dev/'


def validate():
    config = json.loads((ROOT / 'wrangler.jsonc').read_text())
    if config.get('name') != WORKER or config.get('account_id') != ACCOUNT:
        raise ValueError('Deployment target changed. Review the Worker and account before deploying.')
    if config.get('assets', {}).get('directory') != './dist':
        raise ValueError('The assets directory must be ./dist.')
    expected = ['index.html', 'style.css', 'campaign.js', 'visuals.js', 'audio.js', 'expansion.js', 'town.js', 'game.js', '_headers',
                'assets/audio/covenant.mp3', 'assets/audio/combat.mp3', 'assets/audio/bellkeeper.mp3',
                'assets/town-buildings.png', 'assets/town-backdrop.png', 'assets/town-residents.png',
                'assets/cathedral-simple.png', 'assets/characters-simple.png', 'assets/scenery-simple.png', 'assets/villagers.png',
                'assets/region-props.png', 'assets/covenant-scenes.png', 'assets/journey-scenes.png']
    for name in expected:
        path = ROOT / 'dist' / name
        if not path.is_file() or not path.stat().st_size:
            raise ValueError(f'Missing game asset: {name}')
    files = [p for p in (ROOT / 'dist').rglob('*') if p.is_file()]
    for p in files:
        if p.is_symlink() or p.stat().st_size > 25 * 1024 * 1024:
            raise ValueError(f'Asset unsupported by Cloudflare: {p.relative_to(ROOT)}')
    print(f'Validated {len(files)} static files for {URL}')


def api(path, token):
    request = urllib.request.Request('https://api.cloudflare.com/client/v4' + path,
                                    headers={'Authorization': 'Bearer ' + token, 'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            body = json.load(response)
    except urllib.error.HTTPError as error:
        raise RuntimeError(f'Cloudflare preflight returned HTTP {error.code}. Check the account-scoped token permissions.') from None
    except urllib.error.URLError:
        raise RuntimeError('Cloudflare preflight could not connect. Check the environment network policy.') from None
    if not body.get('success'):
        raise RuntimeError('Cloudflare preflight rejected the request. Check token permissions and account access.')
    return body['result']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only', action='store_true', help='Validate local files without authentication or network access')
    parser.add_argument('--wrangler', default='wrangler', help='Path to the installed official Wrangler CLI')
    args = parser.parse_args()
    validate()
    if args.check_only:
        return
    token = os.environ.get('CLOUDFLARE_API_TOKEN')
    if not token:
        raise RuntimeError('Configure CLOUDFLARE_API_TOKEN as a secure environment secret before deployment. Do not paste it into chat.')
    domain = api(f'/accounts/{ACCOUNT}/workers/subdomain', token)
    if domain.get('subdomain') != SUBDOMAIN:
        raise RuntimeError('The account Workers subdomain differs from certifiedcoal. No deployment was attempted.')
    workers = api(f'/accounts/{ACCOUNT}/workers/scripts', token)
    if not any(w.get('id') == WORKER for w in workers):
        raise RuntimeError('The existing Worker was not found in this account. No deployment was attempted.')
    print(f'Existing Worker verified: {WORKER}. Publishing the static game…', flush=True)
    env = os.environ.copy()
    env['CLOUDFLARE_ACCOUNT_ID'] = ACCOUNT
    env['WRANGLER_SEND_METRICS'] = 'false'
    env['WRANGLER_LOG'] = 'warn'
    result = subprocess.run([args.wrangler, 'deploy', '--config', str(ROOT / 'wrangler.jsonc')],
                            cwd=ROOT, env=env, capture_output=True, text=True)
    output = (result.stdout + result.stderr).replace(token, '[redacted]')
    if result.returncode:
        print(output[-4000:], file=sys.stderr)
        raise RuntimeError('Wrangler did not complete deployment. The message above is credential-redacted.')
    print(output[-2500:])
    print(f'Deployed Determent: {URL}')


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, ValueError, OSError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
